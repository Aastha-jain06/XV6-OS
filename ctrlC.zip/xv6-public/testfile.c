#include "types.h" 
#include "stat.h" 
#include "user.h"



int main() {
    int count = 1;

    while (count <= 100000) {
        printf(1, "Count:");
        count++;  // Increment the count
    }

    exit();
}
